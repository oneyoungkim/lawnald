"use client";

import { API_BASE } from "@/lib/api";

import { useState, useEffect } from "react";
import {
    DocumentTextIcon,
    SparklesIcon,
    ClipboardDocumentIcon,
    ArrowDownTrayIcon,
    CheckIcon,
} from "@heroicons/react/24/outline";
import ReactMarkdown from "react-markdown";

interface Matter {
    id: string;
    title: string;
    case_number: string;
    court: string;
    client_name: string;
    opponent_name: string;
    description: string;
}

const DOC_TYPES = [
    { key: "complaint", name: "소장", icon: "📄", desc: "민사소송 소장" },
    { key: "answer", name: "답변서", icon: "📋", desc: "피고 답변서" },
    { key: "brief", name: "준비서면", icon: "📝", desc: "변론 준비서면" },
    { key: "payment_order", name: "지급명령", icon: "💰", desc: "지급명령 신청" },
    { key: "power_of_attorney", name: "위임장", icon: "🤝", desc: "소송 위임장" },
    { key: "settlement", name: "합의서", icon: "🤲", desc: "분쟁 합의서" },
    { key: "demand_letter", name: "내용증명", icon: "✉️", desc: "내용증명 우편" },
    { key: "provisional_attachment", name: "가압류", icon: "🔒", desc: "부동산/채권 가압류" },
    { key: "criminal_complaint", name: "고소장", icon: "⚖️", desc: "형사 고소장" },
    { key: "statement", name: "진술서", icon: "🗣️", desc: "사실 진술서" },
    { key: "retainer_agreement", name: "수임계약서", icon: "📑", desc: "법률사무 위임계약" },
    { key: "appeal", name: "항소장", icon: "🔼", desc: "항소 제기" },
    { key: "provisional_injunction", name: "가처분", icon: "🚫", desc: "처분금지 가처분" },
];

export default function DocAutomationPage() {
    const [selectedType, setSelectedType] = useState<string>("");
    const [matters, setMatters] = useState<Matter[]>([]);
    const [selectedMatter, setSelectedMatter] = useState<string>("");
    const [form, setForm] = useState({
        plaintiff_name: "", defendant_name: "", court: "", case_number: "",
        case_summary: "", claim_amount: "", additional_info: "",
    });
    const [result, setResult] = useState<string>("");
    const [loading, setLoading] = useState(false);
    const [copied, setCopied] = useState(false);

    // Load matters
    useEffect(() => {
        fetch(`${API_BASE}/api/matters`).then(r => r.json()).then(setMatters).catch(() => { });
    }, []);

    // Auto-fill from matter
    const handleMatterSelect = (matterId: string) => {
        setSelectedMatter(matterId);
        const m = matters.find(x => x.id === matterId);
        if (m) {
            setForm(prev => ({
                ...prev,
                plaintiff_name: m.client_name || prev.plaintiff_name,
                defendant_name: m.opponent_name || prev.defendant_name,
                court: m.court || prev.court,
                case_number: m.case_number || prev.case_number,
                case_summary: m.description || prev.case_summary,
            }));
        }
    };

    const generate = async () => {
        if (!selectedType) return;
        setLoading(true);
        setResult("");
        try {
            const res = await fetch(`${API_BASE}/api/documents/generate`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ doc_type: selectedType, matter_id: selectedMatter || undefined, ...form }),
            });
            if (res.ok) {
                const data = await res.json();
                setResult(data.content);
            } else {
                const err = await res.json();
                setResult(`❌ 오류: ${err.detail || "문서 생성에 실패했습니다."}`);
            }
        } catch (err) {
            setResult("❌ 네트워크 오류가 발생했습니다.");
        } finally {
            setLoading(false);
        }
    };

    const copyToClipboard = () => {
        navigator.clipboard.writeText(result);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
    };

    const downloadTxt = () => {
        const blob = new Blob([result], { type: "text/plain;charset=utf-8" });
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        const docName = DOC_TYPES.find(d => d.key === selectedType)?.name || "문서";
        a.download = `${docName}_${new Date().toISOString().split("T")[0]}.txt`;
        a.click();
        URL.revokeObjectURL(url);
    };

    return (
        <div className="min-h-screen bg-[#F5F5F7] dark:bg-zinc-950">
            {/* Header */}
            <header className="bg-white dark:bg-zinc-900 border-b border-zinc-200 dark:border-zinc-800 px-6 py-5">
                <div className="max-w-5xl mx-auto">
                    <h1 className="text-2xl font-bold text-zinc-900 dark:text-white tracking-tight">문서 자동화</h1>
                    <p className="text-sm text-zinc-500 mt-1">AI가 법률 서면을 자동으로 작성합니다. 사건 데이터를 연동하면 더 정확한 문서가 생성됩니다.</p>
                </div>
            </header>

            <div className="max-w-5xl mx-auto px-6 py-6 space-y-6">
                {/* Step 1: Select Document Type */}
                <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6">
                    <h2 className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-4">① 문서 유형 선택</h2>
                    <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                        {DOC_TYPES.map(doc => (
                            <button
                                key={doc.key}
                                onClick={() => setSelectedType(doc.key)}
                                className={`p-4 rounded-2xl border-2 text-center transition-all hover:scale-[1.02] active:scale-[0.98] ${selectedType === doc.key
                                    ? "border-blue-500 bg-blue-50 dark:bg-blue-900/20 shadow-lg shadow-blue-100 dark:shadow-none"
                                    : "border-zinc-100 dark:border-zinc-800 hover:border-zinc-200"
                                    }`}
                            >
                                <span className="text-2xl block mb-2">{doc.icon}</span>
                                <span className="text-xs font-bold text-zinc-900 dark:text-white block">{doc.name}</span>
                                <span className="text-[10px] text-zinc-400 block mt-0.5">{doc.desc}</span>
                            </button>
                        ))}
                    </div>
                </div>

                {/* Step 2: Input Details */}
                {selectedType && (
                    <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6">
                        <h2 className="text-xs font-black text-zinc-400 uppercase tracking-widest mb-4">② 사건 정보 입력</h2>

                        {/* Matter Link */}
                        {matters.length > 0 && (
                            <div className="mb-4">
                                <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">사건 연동 (선택)</label>
                                <select
                                    value={selectedMatter}
                                    onChange={e => handleMatterSelect(e.target.value)}
                                    className="w-full p-3 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500"
                                >
                                    <option value="">직접 입력</option>
                                    {matters.map(m => (
                                        <option key={m.id} value={m.id}>{m.title} {m.case_number ? `(${m.case_number})` : ""}</option>
                                    ))}
                                </select>
                                <p className="text-[10px] text-zinc-400 mt-1">사건을 선택하면 당사자, 법원, 사건번호가 자동으로 채워집니다</p>
                            </div>
                        )}

                        {/* Dynamic fields per document type */}
                        {(() => {
                            const t = selectedType;
                            // Civil litigation: 소장, 답변서, 준비서면, 항소장
                            if (["complaint", "answer", "brief", "appeal"].includes(t)) return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label={t === "answer" ? "원고" : "원고 (의뢰인)"} value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label={t === "answer" ? "피고 (의뢰인)" : "피고 (상대방)"} value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                        <InputField label="사건번호" value={form.case_number} onChange={v => setForm({ ...form, case_number: v })} placeholder="2024가단12345" />
                                    </div>
                                    {t !== "brief" && <div className="mb-4"><InputField label="청구금액" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="50,000,000원" /></div>}
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t === "complaint" ? "청구원인 (사건 경위)" : t === "answer" ? "답변 및 항변 내용" : t === "brief" ? "변론할 쟁점 및 주장" : "항소 이유"}</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder={t === "complaint" ? "사건의 경위와 청구 원인을 시간순서로 상세히 기술하세요..." : t === "answer" ? "원고 주장에 대한 인부, 항변 및 반박 내용..." : t === "brief" ? "이전 변론에 대한 의견, 쟁점별 법적 논증..." : "제1심 판결의 사실오인, 법리오해 등 항소 이유..."} />
                                    </div>
                                </>
                            );
                            // Payment: 지급명령
                            if (t === "payment_order") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="채권자 (신청인)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="채무자 (상대방)" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                        <InputField label="청구금액" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="50,000,000원" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">채권 발생 원인</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="대여금/물품대금/용역대금 등 채권 발생 경위, 변제기, 독촉 경위 등..." />
                                    </div>
                                </>
                            );
                            // Power of attorney: 위임장
                            if (t === "power_of_attorney") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="위임인 (의뢰인)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="상대방" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                        <InputField label="사건번호" value={form.case_number} onChange={v => setForm({ ...form, case_number: v })} placeholder="2024가단12345" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">위임사무 내용</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[80px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="소송 사건명, 위임 범위 등..." />
                                    </div>
                                </>
                            );
                            // Settlement: 합의서
                            if (t === "settlement") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="갑 (피해자/채권자)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="을 (가해자/채무자)" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="mb-4">
                                        <InputField label="합의금액" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="10,000,000원" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">분쟁 내용 및 합의 조건</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="분쟁 발생 경위, 합의 조건 (분할 지급, 고소 취하 여부 등)..." />
                                    </div>
                                </>
                            );
                            // Demand letter: 내용증명
                            if (t === "demand_letter") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="발신인 (통고인)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="수신인 (피통고인)" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="mb-4">
                                        <InputField label="최고 금액" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="50,000,000원" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">통고 사유 및 최고 내용</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="사건의 경위, 법적 근거, 이행 최고 사항 (7일 이내 지급 등)..." />
                                    </div>
                                </>
                            );
                            // Provisional attachment/injunction: 가압류, 가처분
                            if (["provisional_attachment", "provisional_injunction"].includes(t)) return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="채권자 (신청인)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="채무자 (피신청인)" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                        <InputField label="피보전채권액" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="100,000,000원" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{t === "provisional_attachment" ? "피보전권리 및 보전 필요성" : "피보전권리 및 처분금지 사유"}</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder={t === "provisional_attachment" ? "채권 발생 원인, 채무자의 재산은닉/처분 우려, 목적물 표시..." : "피보전권리(소유권/임차권 등), 처분 우려 사유, 목적물 표시..."} />
                                    </div>
                                </>
                            );
                            // Criminal complaint: 고소장
                            if (t === "criminal_complaint") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="고소인" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="피고소인" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순 (불상인 경우 '성명불상')" />
                                    </div>
                                    <div className="mb-4">
                                        <InputField label="혐의 죄명" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="사기 / 횡령 / 배임 / 폭행 / 명예훼손 등" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">고소 사실 (범행 경위 및 피해 내용)</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[150px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="범행일시, 장소, 경위를 시간순서로 기술하세요.&#10;예: 2024년 3월 피고소인은 투자금 명목으로 5천만원을 편취하였고..." />
                                    </div>
                                </>
                            );
                            // Statement: 진술서
                            if (t === "statement") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="진술인" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="관련 사건 당사자" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="해당 사건의 원고/피고" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                        <InputField label="사건번호" value={form.case_number} onChange={v => setForm({ ...form, case_number: v })} placeholder="2024가단12345" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">진술 내용 (목격·경험 사실)</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[150px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="직접 경험하거나 목격한 사실을 시간순서로 상세히 기술하세요..." />
                                    </div>
                                </>
                            );
                            // Retainer: 수임계약서
                            if (t === "retainer_agreement") return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="의뢰인 (갑)" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="수임변호사 (을)" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="변호사 김변" />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="착수금" value={form.claim_amount} onChange={v => setForm({ ...form, claim_amount: v })} placeholder="3,000,000원" />
                                        <InputField label="성공보수 (비율 또는 금액)" value={form.case_number} onChange={v => setForm({ ...form, case_number: v })} placeholder="경제적 이익의 10% 또는 5,000,000원" />
                                    </div>
                                    <div className="mb-4">
                                        <InputField label="관할법원" value={form.court} onChange={v => setForm({ ...form, court: v })} placeholder="서울중앙지방법원" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">위임사무 내용</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[100px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="소송/자문/형사변호 등 위임사무 유형, 사건 내용, 상대방 등..." />
                                    </div>
                                </>
                            );
                            // Default fallback
                            return (
                                <>
                                    <div className="grid grid-cols-2 gap-4 mb-4">
                                        <InputField label="당사자 1" value={form.plaintiff_name} onChange={v => setForm({ ...form, plaintiff_name: v })} placeholder="홍길동" />
                                        <InputField label="당사자 2" value={form.defendant_name} onChange={v => setForm({ ...form, defendant_name: v })} placeholder="김갑순" />
                                    </div>
                                    <div className="mb-4">
                                        <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">내용</label>
                                        <textarea className="w-full p-4 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[120px]" value={form.case_summary} onChange={e => setForm({ ...form, case_summary: e.target.value })}
                                            placeholder="상세 내용을 입력하세요..." />
                                    </div>
                                </>
                            );
                        })()}

                        <div className="mb-4">
                            <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">추가 지시사항</label>
                            <textarea
                                className="w-full p-3 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500 min-h-[60px]"
                                value={form.additional_info}
                                onChange={e => setForm({ ...form, additional_info: e.target.value })}
                                placeholder="예: 손해배상청구 포함, 특정 법률 조항 인용 등..."
                            />
                        </div>

                        <button
                            onClick={generate}
                            disabled={loading || !form.case_summary.trim()}
                            className="w-full flex items-center justify-center gap-3 py-4 bg-zinc-900 dark:bg-white text-white dark:text-zinc-900 rounded-2xl font-bold text-sm shadow-lg hover:scale-[1.01] active:scale-[0.99] transition-all disabled:opacity-50"
                        >
                            {loading ? (
                                <>
                                    <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                                    AI가 문서를 작성하고 있습니다...
                                </>
                            ) : (
                                <>
                                    <SparklesIcon className="w-5 h-5" /> 문서 생성
                                </>
                            )}
                        </button>
                    </div>
                )}

                {/* Step 3: Result */}
                {result && (
                    <div className="bg-white dark:bg-zinc-900 rounded-3xl border border-zinc-200 dark:border-zinc-800 p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h2 className="text-xs font-black text-zinc-400 uppercase tracking-widest">③ 생성된 문서</h2>
                            <div className="flex items-center gap-2">
                                <button onClick={copyToClipboard} className="flex items-center gap-1.5 px-4 py-2 bg-zinc-100 dark:bg-zinc-800 rounded-xl text-xs font-bold text-zinc-600 hover:bg-zinc-200 transition-colors">
                                    {copied ? <CheckIcon className="w-3.5 h-3.5 text-green-500" /> : <ClipboardDocumentIcon className="w-3.5 h-3.5" />}
                                    {copied ? "복사됨" : "복사"}
                                </button>
                                <button onClick={downloadTxt} className="flex items-center gap-1.5 px-4 py-2 bg-zinc-100 dark:bg-zinc-800 rounded-xl text-xs font-bold text-zinc-600 hover:bg-zinc-200 transition-colors">
                                    <ArrowDownTrayIcon className="w-3.5 h-3.5" /> 다운로드
                                </button>
                            </div>
                        </div>
                        <div className="bg-zinc-50 dark:bg-zinc-800 rounded-2xl p-8 prose prose-sm dark:prose-invert max-w-none leading-relaxed">
                            <ReactMarkdown>{result}</ReactMarkdown>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

function InputField({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder?: string }) {
    return (
        <div>
            <label className="block text-[10px] font-black text-zinc-400 uppercase tracking-widest mb-1">{label}</label>
            <input
                className="w-full p-3 bg-zinc-50 dark:bg-zinc-800 rounded-xl text-sm border-0 outline-none focus:ring-2 focus:ring-blue-500"
                value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
            />
        </div>
    );
}
